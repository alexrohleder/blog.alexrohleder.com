# minimal-form

A refactored codrop's minimal form cleaner and with SASS and jQuery.
See the blog post [here](https://blog.alexrohleder.com.br/2016/singleline-form.html).
